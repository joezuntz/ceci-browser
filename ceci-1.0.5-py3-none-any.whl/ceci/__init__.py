from .stage import PipelineStage
from .pipeline import Pipeline, MiniPipeline, ParslPipeline, DryRunPipeline
from pkg_resources import DistributionNotFound
from pkg_resources import get_distribution

__version__ = '1.0.5'