# This file must exist with these contents
from . import *

if __name__ == '__main__':
    PipelineStage.main()
